﻿/*
Problem 3. Occurrences of word

Write a function that finds all the occurrences of word in a text.
The search can be case sensitive or case insensitive.
Use function overloading.
*/

function OccurOfWord() {
    var caseSensitive = false, index = 0, counter = 0, text = "Write a function that finds all the occurrences of word in a text. The search can be case sensitive or case insensitive. Use function overloading.", wordToFind = "a";
    switch (caseSensitive) {
        case true: {
            text = text.toLowerCase();
            wordToFind = wordToFind.toLowerCase();
            while(index <= text.length){
                index = text.indexOf(wordToFind, index);
                if (index === -1) {
                    if (counter === 0) {
                        console.log("The word doesn't exist!");
                        break;
                    } else {
                        break;
                    }
                } else {
                    index += wordToFind.length;
                    counter += 1;
                }
            }
            console.log(counter);
        }
        case false: {
            while (index <= text.length) {
                index = text.indexOf(wordToFind, index);
                if (index === -1) {
                    if (counter === 0) {
                        console.log("The word doesn't exist!");
                        break;
                    } else {
                        break;
                    }
                } else {
                    index += wordToFind.length;
                    counter += 1;
                }
            }
            console.log(counter);
        }
    }
}

