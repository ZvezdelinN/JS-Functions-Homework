﻿/*
Problem 5. Appearance count

Write a function that counts how many times given number appears in given array.
Write a test function to check if the function is working correctly.
*/

var numberToFind = 1, counter = 0, array = [10, 3, 7, 3, 9, 7, 10, 2, 56, 27, 43, 56, 99], arrayLength = array.length;
counter = AppCount(numberToFind);
if (counter === 0) {
    console.log("The number " + numberToFind + " doesn't present in the array ");
} else {
    console.log("The number " + numberToFind + " presents " + counter + " times in the array!");
}

function AppCount(aNumber) {
    for (var i = 0; i < arrayLength; i++) {
        if (array[i] === aNumber) {
            counter += 1;
        }
    }
    return counter;
}