﻿/*
Problem 4. Number of elements

Write a function to count the number of div elements on the web page
*/

function DivCount() {
    var count = document.getElementsByTagName('div').length;
    console.log(count);
}
