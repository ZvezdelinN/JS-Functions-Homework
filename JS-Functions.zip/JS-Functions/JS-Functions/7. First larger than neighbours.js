﻿/*
Problem 7. First larger than neighbours

Write a function that returns the index of the first element in array that is larger than its neighbours or -1, if there’s no such element.
Use the function from the previous exercise.
*/

var index, found = false, array = [10, 3, 7, 3, 9, 7, 10, 2, 56, 27, 43, 56, 99], arrayLength = array.length;
index = LagerThanNeighbours();
if (index > -1) {
    console.log("Yes, the element at position " + index + " is larger than his two neigbours!");
} else {
    console.log("There is not such element!");
}

function LagerThanNeighbours() {
    var indexOf = -1;
    for (var i = 1; i < arrayLength - 2; i++) {
        if (array[i] > array[i-1] && array[i] > array[i+1]) {
            indexOf = array.indexOf(array[i]);
            break;
        } 
    }

    return indexOf;
}