﻿/*
Problem 6. Larger than neighbours

Write a function that checks if the element at given position in given array of integers is bigger than its two neighbours (when such exist).
*/

var position = 2, array = [10, 3, 7, 3, 9, 7, 10, 2, 56, 27, 43, 56, 99], arrayLength = array.length;
LagerThanNeighbours(position);

function LagerThanNeighbours(aposition) {
    if (position < 0 || position >= arrayLength) {
        console.log("Position is out of range!");
    } else {
        if (position - 1 < 0 || position + 1 === arrayLength) {
            console.log("The element at position " + position + " doesn't has two neighbours!");
        } else {
            if (array[position] > array[position - 1] && array[position] > array[position + 1]) {
                console.log("Yes, the element at position " + position + " is larger than his two neigbours!");
            } else {
                console.log("No, the element at position " + position + " isn't larger than his two neigbours!");
            }
        }
    }
}