﻿/*
Problem 2. Reverse number

Write a function that reverses the digits of given decimal number.
Example:

input	output
256	    652
123.45	54.321
*/

function ReverseNumber() {
    var number = "8.367564", array = [], arrayLength, buffer, result = 0, noIteration = true;
    
    array = number.split(".");
    arrayLength = array.length;
    if (arrayLength < 1 || arrayLength > 2) {
        console.log("Not a number!");
        return;
    } else {
        for (var i = 0; i < arrayLength; i++) {
            buffer = array[i];
            for (var j = buffer.length - 1; j >= 0 ; j--) {
                if (buffer[j] >= 0 || buffer[j] <= 9) {
                    result += +buffer[j] * Math.pow(10, j);
                } else {
                    console.log("Not a number!");
                    return;
                }
            }
            if (arrayLength > 1 && oneIteration) {
                result /= Math.pow(10, buffer.length);
                noIteration = false;
            }
        }
    }
    console.log(result);
}